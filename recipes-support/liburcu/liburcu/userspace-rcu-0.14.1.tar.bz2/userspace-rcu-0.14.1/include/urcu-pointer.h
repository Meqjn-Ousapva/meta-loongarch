#include <urcu/pointer.h>
